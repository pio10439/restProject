const fs = require('fs');
const path = require('path');
const express = require('express');
const https = require('https');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const API_KEY = '809dd210fb1a4d92930e6892';
const api_url = `https://v6.exchangerate-api.com/v6/${API_KEY}/latest/USD`;

const formsDirectory = path.join(__dirname, 'pytania');

if (!fs.existsSync(formsDirectory)) {
    fs.mkdirSync(formsDirectory);
}

app.post('/save-form', (req, res) => {
    const formData = req.body;
    const fileName = `formularz${getNextFormNumber()}.txt`;
    const filePath = path.join(formsDirectory, fileName);
    const content = `Imię: ${formData.name}\nEmail: ${formData.email}\nWiadomość: ${formData.message}\n\n`;

    fs.writeFile(filePath, content, err => {
        if (err) {
            console.error('Error saving form:', err);
            res.status(500).send('Internal Server Error');
        } else {
            console.log('Form saved successfully:', fileName);
        }
    });
});

function getNextFormNumber() {
    let formNumber = 1;
    while (fs.existsSync(path.join(formsDirectory, `formularz${formNumber}.txt`))) {
        formNumber++;
    }
    return formNumber;
}

app.use(express.static(path.join(__dirname, 'public')));

app.get('/rates', (req, res) => {
    https.get(api_url, response => {
        let data = '';

        response.on('data', chunk => {
            data += chunk;
        });

        response.on('end', () => {
            try {
                const jsonData = JSON.parse(data);
                res.json(jsonData.conversion_rates);
            } catch (error) {
                console.error('Error parsing JSON:', error);
                res.status(500).send('Error parsing JSON');
            }
        });
    }).on('error', error => {
        console.error('Error fetching currencies:', error);
        res.status(500).send('Error fetching currencies');
    });
});

const loginRouter = require('./login');
app.use(loginRouter);

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
