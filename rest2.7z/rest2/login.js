const express = require('express');
const fs = require('fs');
const router = express.Router();

router.post('/login', (req, res) => {
    const { username, password } = req.body;

    fs.readFile('users.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Błąd odczytu pliku users.json:', err);
            return res.status(500).json({ success: false, message: "Wewnętrzny błąd serwera" });
        }

        try {
            const users = JSON.parse(data);

            const user = users.find(user => user.username === username && user.password === password);
            if (user) {
                return res.json({ success: true, message: "Pomyślnie zalogowano użytkownika" });
            } else {
                return res.status(401).json({ success: false, message: "Nieprawidłowa nazwa użytkownika lub hasło" });
            }
        } catch (error) {
            console.error('Błąd parsowania danych z pliku users.json:', error);
            return res.status(500).json({ success: false, message: "Wewnętrzny błąd serwera" });
        }
    });
});

module.exports = router;
