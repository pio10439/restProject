const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const userDataPath = path.join(__dirname, 'users.json');


router.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    console.log('Received registration request:', { username, email, password });

    try {
        let users = [];
        if (fs.existsSync(userDataPath)) {
            const userData = fs.readFileSync(userDataPath, 'utf8');
            users = JSON.parse(userData);
        }

        if (users.some(user => user.username === username || user.email === email)) {
            return res.status(400).send('Użytkownik o podanej nazwie użytkownika lub adresie e-mail już istnieje');
        }

        if (!isValidPassword(password)) {
            return res.status(400).send('Password does not meet requirements');
        }

        users.push({ username, email, password });

        fs.writeFileSync(userDataPath, JSON.stringify(users, null, 2), 'utf8');

        console.log('User registered successfully:', username);
        console.log('Updated users:', users);

        res.status(200).send('User registered successfully');
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).send('Internal Server Error');
    }
});

function isValidPassword(password) {
    const regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
    return regex.test(password);
}

module.exports = router;
