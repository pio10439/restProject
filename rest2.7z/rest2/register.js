const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const userDataPath = path.join(__dirname, '..', 'users.json');

router.post('/register', (req, res) => {
    const { username, password } = req.body;

    fs.readFile(userDataPath, 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading user data:', err);
            return res.status(500).send('Internal Server Error');
        }

        let users = [];
        if (data) {
            users = JSON.parse(data);
        }

        if (users.some(user => user.username === username)) {
            return res.status(400).send('User already exists');
        }

        users.push({ username, password });

        fs.writeFile(userDataPath, JSON.stringify(users), 'utf8', err => {
            if (err) {
                console.error('Error writing user data:', err);
                return res.status(500).send('Internal Server Error');
            }
            console.log('User registered successfully:', username);
            res.status(200).send('User registered successfully');
        });
    });
});

module.exports = router;
